package ru.job4j.generics;

public class Tiger extends Predator {
    public Tiger(int paws, String family) {
        super(paws, family);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
