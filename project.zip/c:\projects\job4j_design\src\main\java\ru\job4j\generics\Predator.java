package ru.job4j.generics;

public class Predator extends Animal {
    public Predator(int paws, String family) {
        super(paws, family);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
